﻿using UnityEngine;
using System.Collections;

public class UIViewMain : UIView
{
}
