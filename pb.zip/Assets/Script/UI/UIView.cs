﻿using UnityEngine;
using System.Collections;

public class UIView : MonoBehaviour
{
	
}
