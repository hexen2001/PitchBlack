﻿using UnityEngine;
using System.Collections;

public class UIViewWorldMap : UIView
{

}
