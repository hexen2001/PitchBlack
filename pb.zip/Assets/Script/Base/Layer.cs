﻿
public enum Layer : int
{
	Human = 8,
	HitMonster = 9,
	Dialog = 10,
	HitDialog = 11,
	Monster = 12,
	HitHuman = 13,
}
