﻿using UnityEngine;
using System.Collections;

public abstract class Dialog : MonoBehaviour
{
	public abstract void DrawView ();
}
