﻿using UnityEngine;
using System.Collections;

public class Turret : Character
{


}
